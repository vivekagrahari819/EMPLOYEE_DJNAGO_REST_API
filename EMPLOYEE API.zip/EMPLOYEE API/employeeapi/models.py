from django.db import models


class AddressDetails(models.Model):
    hno = models.CharField(max_length=50)
    street = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)

    def __str__(self):
        return f'{self.hno}, {self.street}, {self.city}, {self.state}'


class WorkExperience(models.Model):
    company_name = models.CharField(max_length=100)
    from_date = models.DateField()
    to_date = models.DateField()
    address = models.CharField(max_length=200)

    def __str__(self):
        return f'{self.company_name} ({self.from_date} - {self.to_date})'


class Qualification(models.Model):
    qualification_name = models.CharField(max_length=100)
    from_date = models.DateField()
    to_date = models.DateField()
    percentage = models.FloatField()

    def __str__(self):
        return f'{self.qualification_name} ({self.from_date} - {self.to_date})'


class Project(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.title


class Employee(models.Model):
    regid = models.CharField(max_length=20, unique=True , default='001')
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    phone_no = models.CharField(max_length=20)
    address_details = models.OneToOneField(AddressDetails, on_delete=models.CASCADE)
    work_experience = models.ManyToManyField(WorkExperience)
    qualifications = models.ManyToManyField(Qualification)
    projects = models.ManyToManyField(Project)
    photo = models.TextField(null=True, blank=True)


    def save(self, *args, **kwargs):
        if not self.id:
            # Generate regid based on id
            self.regid = 'E{:04d}'.format(Employee.objects.count() + 1)
        super().save(*args, **kwargs)
        
    def __str__(self):
        return self.regid


