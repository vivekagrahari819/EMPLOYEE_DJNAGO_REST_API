from django.contrib import admin
from .models import Employee, AddressDetails, WorkExperience, Qualification, Project

class AddressDetailsAdmin(admin.ModelAdmin):
   list_display = ('id', 'hno', 'street', 'city', 'state')
search_fields = ('hno', 'street', 'city', 'state')
list_filter = ('state',)

class WorkExperienceAdmin(admin.ModelAdmin):
   list_display = ('id', 'company_name', 'from_date', 'to_date', 'address')
search_fields = ('company_name', 'address')
list_filter = ('company_name', 'from_date', 'to_date')

class QualificationAdmin(admin.ModelAdmin):
   list_display = ('id', 'qualification_name', 'from_date', 'to_date', 'percentage')
search_fields = ('qualification_name',)
list_filter = ('from_date', 'to_date', 'percentage')

class ProjectAdmin(admin.ModelAdmin):
   list_display = ('id', 'title')
search_fields = ('title',)

class EmployeeAdmin(admin.ModelAdmin):
   list_display = ('id', 'regid', 'name', 'email', 'age', 'gender', 'phone_no')
search_fields = ('name', 'email', 'gender', 'phone_no')
list_filter = ('gender', 'age', 'work_experience', 'qualifications', 'projects')

admin.site.register(AddressDetails, AddressDetailsAdmin)
admin.site.register(WorkExperience, WorkExperienceAdmin)
admin.site.register(Qualification, QualificationAdmin)
admin.site.register(Project, ProjectAdmin)
admin.site.register(Employee, EmployeeAdmin)



