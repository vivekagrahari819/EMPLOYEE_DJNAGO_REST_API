from django.urls import path, include
from rest_framework import routers
from .views import EmployeeViewSet, AddressDetailsViewSet, WorkExperienceViewSet, QualificationViewSet, ProjectViewSet


router = routers.DefaultRouter()
router.register('employees', EmployeeViewSet)
router.register('address_details', AddressDetailsViewSet)
router.register('work_experience', WorkExperienceViewSet)
router.register('qualifications', QualificationViewSet)
router.register('projects', ProjectViewSet)

urlpatterns = [
    path('', include(router.urls)),
   
]





'''

GET /employees/: List all employees

POST /employees/: Create a new employee

GET /employees/<id>/: Retrieve a single employee by id

PUT /employees/<id>/: Update a single employee by id

PATCH /employees/<id>/: Partially update a single employee by id

DELETE /employees/<id>/: Delete a single employee by id

GET /address_details/: List all address details

POST /address_details/: Create a new address detail

GET /address_details/<id>/: Retrieve a single address detail by id

PUT /address_details/<id>/: Update a single address detail by id

PATCH /address_details/<id>/: Partially update a single address detail by id

DELETE /address_details/<id>/: Delete a single address detail by id

GET /work_experience/: List all work experiences

POST /work_experience/: Create a new work experience

GET /work_experience/<id>/: Retrieve a single work experience by id

PUT /work_experience/<id>/: Update a single work experience by id

PATCH /work_experience/<id>/: Partially update a single work experience by id

DELETE /work_experience/<id>/: Delete a single work experience by id

GET /qualifications/: List all qualifications

POST /qualifications/: Create a new qualification

GET /qualifications/<id>/: Retrieve a single qualification by id

PUT /qualifications/<id>/: Update a single qualification by id

PATCH /qualifications/<id>/: Partially update a single qualification by id

DELETE /qualifications/<id>/: Delete a single qualification by id

GET /projects/: List all projects

POST /projects/: Create a new project

GET /projects/<id>/: Retrieve a single project by id

PUT /projects/<id>/: Update a single project by id

PATCH /projects/<id>/: Partially update a single project by id

DELETE /projects/<id>/: Delete a single project by id

'''